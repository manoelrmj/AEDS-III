#include <stdio.h>
#include "operacoes.h"

int main(){
    printf("Soma = %d\n",Soma_Numeros(2,2));
    return 0;
}
