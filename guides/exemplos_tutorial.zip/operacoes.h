#ifndef OPERACAO
#define OPERACAO
int Soma_Numeros(int A,int B);
int Subtrai_Numeros(int A,int B);
int Multiplica_Numeros(int A,int B);
int Divide_Numeros(int A,int B);
#endif
