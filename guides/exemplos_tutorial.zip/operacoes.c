#include "operacoes.h"
int Soma_Numeros(int A, int B){
    return A+B;
}
int Subtrai_Numeros(int A, int B){
    return A-B;
}
int Multiplica_Numeros(int A, int B){
    return A*B;
}
int Divide_Numeros(int A, int B){
    return A/B;
}





