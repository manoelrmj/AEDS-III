// Copyright 2015 Universidade Federal de Minas Gerais (UFMG)

#include "stack.h"

void make_stack(stack* s) {
  s->size = 0;
}

int empty(stack* s) {
  return s->size == 0;
}

int size(stack* s) {
  return s->size;
}

SType top(stack* s) {
  return s->array[s->size - 1];
}

void push(SType k, stack* s) {
  s->array[s->size] = k;
  s->size++;
}

void pop(stack* s) {
  s->size--;
}

void copy(stack* s, stack* p) {
  s->size = p->size;
  for (int i = 0; i < p->size; i++) {
    s->array[i] = p->array[i];
  }
}

void free_stack(stack* s) {
}
